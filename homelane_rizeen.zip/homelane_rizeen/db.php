<?php
//server with default setting (user 'root' with no password)
$host = 'localhost';  // server 
$user = 'root';   
$pass = "";   
$database = 'homelane_rizeen';   //Database Name  

// establishing connection
  $conn = mysqli_connect($host,$user,$pass,$database);   

 // for displaying an error msg in case the connection is not established
  if (!$conn) {                                             
    die("Connection failed: " . mysqli_connect_error());     
  }

$query_homelane = "SELECT ID FROM homelane_record";
$result_homelane = mysqli_query($conn, $query_homelane);
    $query_homelane = "CREATE TABLE homelane_record (
      mydate DATETIME NOT NULL,
      price INTEGER NOT NULL,
      bedrooms INTEGER NOT NULL,
      bathrooms DECIMAL(10 , 2 ) NOT NULL,
      sqft_living INTEGER NOT NULL,
      sqft_lot INTEGER NOT NULL,
      floors DECIMAL(10 , 1 ) NOT NULL,
      waterfront INTEGER NOT NULL,
      view INTEGER NOT NULL,
      mycondition INTEGER NOT NULL,
      sqft_above INTEGER NOT NULL,
      sqft_basement INTEGER NOT NULL,
      yr_built INTEGER NOT NULL,
      yr_renovated INTEGER NOT NULL,
      street VARCHAR(512) NOT NULL,
      city VARCHAR(512) NOT NULL,
      statezip VARCHAR(512) NOT NULL,
      country VARCHAR(512) NOT NULL,
      record_id INT NOT NULL AUTO_INCREMENT,
      PRIMARY KEY (record_id)
)";
    $result_homelane = mysqli_query($conn, $query_homelane);

$csv_homelane = 'select record_id from homelane_record where record_id=1';
$csv_query = mysqli_query($conn, $csv_homelane );
$rowcount_csv = mysqli_num_rows($csv_query);
if(!$csv_query || mysqli_num_rows($csv_query)==0){
    $sql = "LOAD DATA INFILE '../../htdocs/homelane_rizeen/data0967ed6.csv' INTO TABLE homelane_record"
. " FIELDS TERMINATED BY ','"
. " LINES TERMINATED BY '\n'"
. " IGNORE 1 LINES";
  if (!($stmt = $conn->query($sql))) {
    echo "\nQuery execute failed: ERRNO: (" . $conn->errno . ") " . $conn->error;
  }
}
