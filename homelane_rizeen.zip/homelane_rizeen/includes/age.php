<!-- Header -->
<?php  include "../header.php" ?>
<?php 
  if(isset($_POST['create'])) 
    {
        $mymin = $_POST['mymin'];
        header("Location: ./age_filter.php?min=" . $mymin);
    }
?>
<!-- BACK button to go to the home page -->
<div class="container">
<a href="home.php" class="btn btn-warning mt-1"> <b> <- Back </b> </a>
<div>

<h1 class="text-center">Age Homes</h1>
  <div class="container">
    <form action="" method="post">

      <div class="form-group">
        <label for="mymin" class="form-label">Built/Renovated Year</label>
        <input type="number" name="mymin"  class="form-control" min="1000" max="2022" required>
      </div>

      <div class="form-group">
        <input type="submit"  name="create" class="btn btn-primary mt-2" value="submit">
      </div>
    </form> 
  </div>
