<!-- Header -->
<?php  include "../header.php" ?>
<?php 
  if(isset($_POST['create'])) 
    {
        $mymax = $_POST['mymax'];
        $mymin = $_POST['mymin'];
        header("Location: ./budget_filter.php?max=" . $mymax . "&min=" . $mymin);
    }
?>
<!-- BACK button to go to the home page -->
<div class="container">
<a href="home.php" class="btn btn-warning mt-1"> <b> <- Back </b> </a>
<div>

<h1 class="text-center">Budget Homes</h1>
  <div class="container">
    <form action="" method="post">
      <div class="form-group">
        <label for="mymax" class="form-label">Max Price</label>
        <input type="text" name="mymax"  class="form-control" required>
      </div>

      <div class="form-group">
        <label for="mymin" class="form-label">Min Price</label>
        <input type="text" name="mymin"  class="form-control" required>
      </div>

      <div class="form-group">
        <input type="submit"  name="create" class="btn btn-primary mt-2" value="submit">
      </div>
    </form> 
  </div>
