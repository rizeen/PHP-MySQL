<!-- Header -->
<?php  include "../header.php" ?>
<?php 
  if (isset($_GET['min'])) {
    $mymin = $_GET['min']; 
  }
?>
<!-- BACK button to go to the home page -->
<div class="container-fluid">
<a href="sqft.php" class="btn btn-warning mt-1"> <b> <- Back </b> </a>
<div>

<h1 class="text-center">Homes above <?php echo $mymin . " Sqft"?> </h1>
  <div class="container-fluid">
    <div class="table-responsive">
        <table class="table">
        <tr>
          <th>
          <?php echo "date" ;?>
          </th>
          <th>
          <?php echo "price" ;?>
          </th>
          <th>
          <?php echo "bedrooms" ;?>
          </th>
          <th>
          <?php echo "bathrooms" ;?>
          </th>
          <th>
          <?php echo "sqft_living" ;?>
          </th>
          <th>
          <?php echo "sqft_lot" ;?>
          </th>
          <th>
          <?php echo "floors" ;?>
          </th>
          <th>
          <?php echo "waterfront" ;?>
          </th>
          <th>
          <?php echo "view" ;?>
          </th>
          <th>
          <?php echo "condition" ;?>
          </th>
          <th>
          <?php echo "sqft_above" ;?>
          </th>
          <th>
          <?php echo "sqft_basement" ;?>
          </th>
          <th>
          <?php echo "yr_built" ;?>
          </th>
          <th>
          <?php echo "yr_renovated" ;?>
          </th>
          <th>
          <?php echo "street" ;?>
          </th>
          <th>
          <?php echo "city" ;?>
          </th>
          <th>
          <?php echo "statezip" ;?>
          </th>
          <th>
          <?php echo "country" ;?>
          </th>
        </tr>
    <?php
$query="SELECT * FROM homelane_record WHERE sqft_living > '$mymin'";                 
$view_users= mysqli_query($conn,$query);            
while($row = mysqli_fetch_assoc($view_users))
{
  ?>
        <tr>
          <td>
          <?php echo $row["mydate"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["price"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["bedrooms"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["bathrooms"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["sqft_living"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["sqft_lot"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["floors"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["waterfront"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["view"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["mycondition"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["sqft_above"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["sqft_basement"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["yr_built"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["yr_renovated"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["street"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["city"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["statezip"] . "<br>";?>
          </td>
          <td>
          <?php echo $row["country"] . "<br>";?>
          </td>
        </tr>
  <?php
}
    ?>
      </table>
    </div>

  </div>

