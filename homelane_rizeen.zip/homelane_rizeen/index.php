<!-- Header -->
<?php include "header.php" ?>

<!-- body -->
<div class="container mt-5">
    <h1 class="text-center">Full stack Application to see Homelane Data</h1>
</div>
<div class="container my-5 list_airlines">
  <a type="button" class="btn btn-success d-flex my-3 mx-auto" href="includes/budget.php" target="_blank">
    Budget Homes (maxPrice, minPrice)
  </a>
  <a type="button" class="btn btn-warning d-flex my-3 mx-auto" href="includes/sqft.php" target="_blank">
    Sqft Homes  (minSqft)
  </a>
  <a type="button" class="btn btn-info d-flex my-3 mx-auto" href="includes/age.php" target="_blank">
    Age Homes  (year)
  </a>
  <a type="button" class="btn btn-danger d-flex my-3 mx-auto" href="includes/standard.php" target="_blank">
    Standardized Prices of all Houses
  </a>
</div>