-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2022 at 07:12 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digital_apple_crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `digital_apple_record`
--
CREATE DATABASE digital_apple_crud;
USE digital_apple_crud;

CREATE TABLE `digital_apple_record` (
  `id` int(12) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `digital_apple_record`
--

INSERT INTO `digital_apple_record` (`id`, `first_name`, `last_name`, `email`, `contact`, `address`) VALUES
(1, 'Rizeen', 'Mujawar', 'rizi.muj@gmail.com', '9702932933', 'Nerul'),
(2, 'aa', 'aa', 'admin@gmail.com', '5444442', 'aa'),
(3, 'zz', 'zz', 'adminzz@gmail.com', '33333333', 'zz');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `digital_apple_record`
--
ALTER TABLE `digital_apple_record`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `digital_apple_record`
--
ALTER TABLE `digital_apple_record`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
