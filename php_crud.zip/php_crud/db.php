<?php
//server with default setting (user 'root' with no password)
$host = 'localhost';  // server 
$user = 'root';   
$pass = "";   
$database = 'digital_apple_crud';   //Database Name  

// establishing connection
  $conn = mysqli_connect($host,$user,$pass,$database);   

 // for displaying an error msg in case the connection is not established
  if (!$conn) {                                             
    die("Connection failed: " . mysqli_connect_error());     
  }


$query_info = "SELECT ID FROM digital_apple_record";
$result_info = mysqli_query($conn, $query_info);
// sql to create table
    $query_info = "CREATE TABLE  digital_apple_record(
    id int(12) NOT NULL AUTO_INCREMENT,
    first_name varchar(255) NOT NULL,
    last_name varchar(255) NOT NULL,
    email varchar(255) NOT NULL,
    contact varchar(255) NOT NULL,
    address varchar(255) NOT NULL,
    PRIMARY KEY (id)
    )";
    $result_info = mysqli_query($conn, $query_info);
