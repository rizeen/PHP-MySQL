<footer class="blockquote-footer fixed-bottom text-center">
    Copyright © 2022 Footer
</footer>
</body>
</html>