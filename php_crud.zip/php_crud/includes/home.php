<!-- Header -->
<?php include "../header.php"?>

  <div class="container">
    <h1 class="text-center mb-3" >CRUD Operations</h1>
      <a href="create.php" class='btn btn-primary mb-3'> <i class="bi bi-person-plus"></i> Insert Record</a>

        <table class="table table-striped table-bordered table-hover">
          <thead class="table-dark">
            <tr>
              <th  scope="col">ID</th>
              <th  scope="col">First Name</th>
              <th  scope="col">Last Name</th>
              <th  scope="col">Email</th>
              <th  scope="col">Contact</th>
              <th  scope="col">Address</th>
              <th  scope="col" colspan="3" class="text-center">CRUD Operations</th>
            </tr>  
          </thead>
            <tbody>
              <tr>
 
          <?php
            $query="SELECT * FROM digital_apple_record";               // SQL query to fetch all table data
            $view_users= mysqli_query($conn,$query);    // sending the query to the database

            //  displaying all the data retrieved from the database using while loop
            if (!empty($view_users)) {
            while($row= mysqli_fetch_assoc($view_users)){
              $id = $row['id'];                
              $first_name = $row['first_name'];        
              $last_name = $row['last_name'];        
              $email = $row['email'];         
              $contact = $row['contact'];
              $address = $row['address'];
      
              echo "<tr >";
              echo " <th scope='row' >{$id}</th>";
              echo " <td > {$first_name}</td>";
              echo " <td > {$last_name}</td>";
              echo " <td > {$email}</td>";
              echo " <td > {$contact}</td>";
              echo " <td >{$address} </td>";

              echo " <td class='text-center'> <a href='view.php?user_id={$id}' class='btn btn-primary'> <i class='bi bi-eye'></i> View</a> </td>";

              echo " <td class='text-center' > <a href='update.php?edit&user_id={$id}' class='btn btn-secondary'><i class='bi bi-pencil'></i> EDIT</a> </td>";

              echo " <td  class='text-center'>  <a href='delete.php?delete={$id}' class='btn btn-danger delete_record'> <i class='bi bi-trash'></i> DELETE</a> </td>";
              echo " </tr> ";
                  }
                }  
                ?>
              </tr>  
            </tbody>
        </table>
  </div>

<!-- BACK button to go to the index page -->
<div class="container text-center mt-5">
      <a href="../index.php" class="btn btn-warning mt-5"> <b> <- Back </b> </a>
<div>

<!-- Footer -->
<?php include "../footer.php" ?>