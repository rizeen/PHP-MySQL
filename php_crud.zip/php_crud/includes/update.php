<!-- Header -->
<?php include "../header.php"?>

<?php
   // checking if the variable is set or not and if set adding the set data value to variable userid
   if(isset($_GET['user_id']))
    {
      $userid = $_GET['user_id']; 
    }
      // SQL query to select all the data from the table where id = $userid
      $query="SELECT * FROM digital_apple_record WHERE id = $userid ";
      $view_users= mysqli_query($conn,$query);

      while($row = mysqli_fetch_assoc($view_users))
        {
          $id = $row['id'];                
          $first_name = $row['first_name'];        
          $last_name = $row['last_name'];        
          $email = $row['email'];         
          $contact = $row['contact'];
          $address = $row['address'];
}
 
    //Processing form data when form is submitted
    if(isset($_POST['update'])) 
    {
      $first_name = $_POST['first_name'];
      $last_name = $_POST['last_name'];
      $email = $_POST['email'];
      $contact = $_POST['contact'];
      $address = $_POST['address'];
            
      // SQL query to update the data in user table where the id = $userid 
      $query = "UPDATE digital_apple_record SET first_name = '{$first_name}' , last_name = '{$last_name}' , email = '{$email}' , contact = '{$contact}' , address = '{$address}' WHERE id = $userid";
      $update_user = mysqli_query($conn, $query);
      echo "<script type='text/javascript'>alert('User data updated successfully!')</script>";
    }             
?>

<!-- BACK button to go to the home page -->
<div class="container">
  <a href="home.php" class="btn btn-warning mt-1"> <b> <- Back </b> </a>
<div>

<h1 class="text-center">Update Record</h1>
  <div class="container ">
    <form action="" method="post">
      <div class="form-group">
        <label for="first_name" class="form-label">First Name</label>
        <input type="text" name="first_name"  class="form-control" value="<?php echo $first_name  ?>" required>
      </div>

      <div class="form-group">
        <label for="last_name" class="form-label">Last Name</label>
        <input type="text" name="last_name"  class="form-control" value="<?php echo $last_name  ?>" required>
      </div>

      <div class="form-group">
        <label for="email" class="form-label">Email id</label>
        <input type="text" name="email"  class="form-control" value="<?php echo $email  ?>" required>
      </div>
    
      <div class="form-group">
        <label for="contact" class="form-label">Contact No.</label>
        <input type="text" name="contact"  class="form-control" value="<?php echo $contact  ?>" required>
      </div>    

      <div class="form-group">
        <label for="address" class="form-label">Address</label>
        <input type="text" name="address"  class="form-control" value="<?php echo $address  ?>" required>
      </div>

      <div class="form-group">
         <input type="submit"  name="update" class="btn btn-primary mt-2" value="update">
      </div>
    </form>    
  </div>

  <!-- Footer -->
<?php include "../footer.php" ?>