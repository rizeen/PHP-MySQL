<!-- Header -->
<?php  include '../header.php'?>

  <h1 class="text-center">Records</h1>
  <div class="container">
    <table class="table table-striped table-bordered table-hover">
      <thead class="table-dark">
        <tr>
          <th  scope="col">ID</th>
          <th  scope="col">First Name</th>
          <th  scope="col">Last Name</th>
          <th  scope="col">Email</th>
          <th  scope="col">Contact</th>
          <th  scope="col">Address</th>
        </tr>  
      </thead>
        <tbody>
          <tr>
               
            <?php
              // check using 'isset()' function if the variable is set or not
              //Processing form data when form is submitted
              if (isset($_GET['user_id'])) {
                  $userid = $_GET['user_id']; 

                  // SQL query to fetch the data where id=$userid & storing data in view_user 
                  $query="SELECT * FROM digital_apple_record WHERE id = {$userid} ";  
                  $view_users= mysqli_query($conn,$query);            

                  while($row = mysqli_fetch_assoc($view_users)){
                    $id = $row['id'];                
                    $first_name = $row['first_name'];        
                    $last_name = $row['last_name'];        
                    $email = $row['email'];         
                    $contact = $row['contact'];
                    $address = $row['address'];
      
                    echo " <td > {$id}</td>";
                    echo " <td > {$first_name}</td>";
                    echo " <td > {$last_name}</td>";
                    echo " <td > {$email}</td>";
                    echo " <td > {$contact} </td>"; 
                    echo " <td > {$address} </td>"; 
                  }
                }
            ?>
          </tr>  
        </tbody>
    </table>
  </div>

   <!-- BACK Button to go to pervious page -->
  <div class="container text-center mt-5">
    <a href="home.php" class="btn btn-warning mt-5"> <b> <- Back </b> </a>
  <div>

<!-- Footer -->
<?php include "../footer.php" ?>