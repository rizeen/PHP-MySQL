<!-- Header -->
<?php include "header.php" ?>

<!-- body -->
<div class="container mt-5">
    <h1 class="text-center">PHP MySQL CRUD Operation App</h1>
  <div class="container">
    <form action="includes/home.php" method="post">
        <div class="from-group text-center">
            <input type="submit" class="btn btn-primary mt-2" value="Click to Test">
        </div>
    </form>
  </div>
</div>

<!-- Footer -->
<?php include "footer.php" ?>